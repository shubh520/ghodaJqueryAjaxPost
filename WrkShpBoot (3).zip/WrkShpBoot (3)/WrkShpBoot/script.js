
var x=0;
function fun()
{
x=x+1;
document.getElementById("demo").innerHTML = x;
}

// // var u="user";
// // function submitting(){
// // //  u=document.getElementById("ipEmail");
// // document.getElementById("username12").innerHTML = u;
// // }

function myFunction() {
    var x = document.getElementById("txtNewPassword");
    if (x.type === "password") {
      x.type = "text";
    } else {
      x.type = "password";
    }
  }

// // function checkPasswordMatch() {
   
// // }
$(document).ready(function () {

    $('#txtConfirmPassword').keyup(function(){
 //  $("#clickPass").click(checkPasswordMatch);

 var password = $("#txtNewPassword").val();
    var confirmPassword = $("#txtConfirmPassword").val();
    if (password != confirmPassword)
        $("#msg").html("Password does not match!").css("color", "red");
    else 
        $("#msg").html("Password match. please submit").css("color", "green");
    });


    $('#clickPass').click(function(){
      $.ajax({
          type: 'POST',
          dataType: 'json',
          url: 'http://localhost:3000/users',
          data: {
              username: $('#ipEmail').val(),
              password: $('#txtNewPassword').val()
            },
          success: function(res){
              console.log('successfully added record in json-server')              
              console.log(res)
          }
      })
  })

});

